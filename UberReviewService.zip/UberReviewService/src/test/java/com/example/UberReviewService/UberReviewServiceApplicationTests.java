package com.example.UberReviewService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UberReviewServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
